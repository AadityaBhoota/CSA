import javax.swing.*;
import java.util.*;

/**
 * Description of the Class
 *
 * @author Aaditya Bhoota
 * period 3
 */

public class Sorts {
    private long steps;

    /**
     * Description of Constructor
     */
    public Sorts() {
        steps = 0;

    }

    /**
     * Description of the Method
     *
     * @param list reference to an array of integers to be sorted
     */
    public void bubbleSort(ArrayList<Comparable> list) {
        // Add your code here
        System.out.println();
        System.out.println("Bubble Sort");
        System.out.println();
        setStepCount(0);
        for (int outer = 0; outer < list.size() - 1; outer++) {
            for (int inner = 0; inner < list.size() - 1 - outer; inner++) {
                setStepCount(steps + 3);
                if (list.get(inner).compareTo(list.get(inner + 1)) > 0) {
                    swap(list, inner, inner + 1);
                }
            }
        }
    }

    /**
     * Description of the Method
     *
     * @param list reference to an array of integers to be sorted
     */
    public void selectionSort(ArrayList<Comparable> list) {
        // Add your code here
        System.out.println();
        System.out.println("Selection Sort");
        System.out.println();
        steps = 0;
        int indexOfMinVal;
        for (int outer = 0; outer < list.size() - 1; outer++) {
            indexOfMinVal = outer;
            for (int inner = outer + 1; inner < list.size(); inner++) {
                steps += 3;
                if (list.get(inner).compareTo(list.get(indexOfMinVal)) < 0) {
                    indexOfMinVal = inner;
                }
            }
            swap(list, outer, indexOfMinVal);
        }
    }

    /**
     * Description of the Method
     *
     * @param list reference to an array of integers to be sorted
     */
    public void insertionSort(ArrayList<Comparable> list) {
        // Add your code here
        System.out.println();
        System.out.println("Insertion Sort");
        System.out.println();
        steps = 0;
        for (int outer = 1; outer < list.size(); outer++) {
            int indexOfCurrentVal = outer;
            Comparable currentVal = list.get(indexOfCurrentVal);
            steps += 3;
            while (indexOfCurrentVal > 0 && list.get(indexOfCurrentVal - 1).compareTo(currentVal) > 0) {
                steps += 4;
                list.set(indexOfCurrentVal, list.get(indexOfCurrentVal - 1));
                indexOfCurrentVal--;
            }
            list.set(indexOfCurrentVal, currentVal);
            steps++;
        }
    }

    /**
     * Takes in entire vector, but will merge the following sections together: Left
     * sublist from a[first]..a[mid], right sublist from a[mid+1]..a[last].
     * Precondition: each sublist is already in ascending order
     *
     * @param a     reference to an array of integers to be sorted
     * @param first starting index of range of values to be sorted
     * @param mid   midpoint index of range of values to be sorted
     * @param last  last index of range of values to be sorted
     */
    private void merge(ArrayList<Comparable> a, int first, int mid, int last) {
        ArrayList<Comparable> temp = new ArrayList<Comparable>(a.size());

        int i = first;
        int j = mid;

        while (i < mid && j <= last) {
            if (a.get(i).compareTo(a.get(j)) > 0) {
                temp.add(a.get(j));
                j++;
            } else {
                temp.add(a.get(i));
                i++;
            }
            steps += 5;
        }
        while (i < mid) {
            temp.add(a.get(i));
            i++;
            steps += 2;
        }
        while (j <= last) {
            temp.add(a.get(j));
            j++;
            steps += 2;
        }
        for (int x = first; x <= last; x++) {
            a.set(x, temp.get(x - first));
            steps += 2;
        }
    }

    /**
     * Recursive merge sort of an array of integers
     *
     * @param a     reference to an array of integers to be sorted
     * @param first starting index of range of values to be sorted
     * @param last  ending index of range of values to be sorted
     */
    public void mergeSort(ArrayList<Comparable> a, int first, int last) {
        steps = 0;
        if (last - first >= 1) {
            int mid = (last + first) / 2;
            mergeSort(a, first, mid);
            mergeSort(a, mid + 1, last);
            merge(a, first, mid + 1, last);
        }
    }

    /**
     * Description of the Method
     *
     * @param a     reference to an array of integers to be sorted
     * @param first starting index of range of values to be sorted
     * @param last  ending index of range of values to be sorted
     */
    public void quickSort(ArrayList<Comparable> a, int first, int last) {
        int mid = (first + last) / 2;
        steps++;
        Comparable midVal = a.get(mid);
        int i = first;
        int j = last;
        do {
            steps += 2;
            while (a.get(i).compareTo(midVal) < 0) {
                steps += 2;
                i++;
            }
            steps += 2;
            while (a.get(j).compareTo(midVal) > 0) {
                steps += 2;
                j--;
            }
            if (i <= j) {
                swap(a, i, j);
                i++;
                j--;
            }
        } while (i < j);
        if (j > first) {
            quickSort(a, first, j);
        }
        if (i < last) {
            quickSort(a, i, last);
        }
    }

    /**
     * Accessor method to return the current value of steps
     *
     * @return number of steps
     */
    public long getStepCount() {
        return steps;
    }

    /**
     * Modifier method to set or reset the step count. Usually called prior to
     * invocation of a sort method.
     *
     * @param stepCount value assigned to steps
     */
    public void setStepCount(long stepCount) {
        steps = stepCount;
    }

    /**
     * Interchanges two elements in an ArrayList
     *
     * @param list   reference to an array of integers
     * @param index1 index of integer to be swapped
     * @param index2 index of integer to be swapped
     */
    public void swap(ArrayList<Comparable> list, int index1, int index2) {
        Comparable temp = list.get(index1);
        list.set(index1, list.get(index2));
        list.set(index2, temp);
        setStepCount(steps + 4);
    }
}