/**
 * @author Aaditya Bhoota
 * Period 3
 */
public class MathFun {
	public void calculate() {
		int answer1 = 4 + 9;
		int answer2 = 46 / 7;
		int answer3 = 46 % 7;
		double answer4 =  2 * 3.0;
		double answer5 = (double)25 / 4;
		int answer6 = (int) 7.75 + 2;
		int answer7 = (int) 'P';
		char answer8 = (char)105;
		System.out.println("4 + 9 = " + answer1);
		System.out.println("46 / 7 = " + answer2);
		System.out.println("46 % 7 = " + answer3);
		System.out.println("2 * 3.0 = " + answer4);
		System.out.println("(double)25 / 4 = " + answer5);
		System.out.println("(int)7.75 + 2 = " + answer6);
		System.out.println("(int)'P' = " + answer7);
		System.out.println("(char)105 = " + answer8);
	}
}

