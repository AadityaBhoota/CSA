/**
 * Last name: Bhoota
 * First name: Aaditya
 * Student ID: 12110538
 * Period: 3
 *
 */
public class Reverse {
	/**
     * Reverses each row of given matrix
     * @param data - matrix to be reversed
     * @return matrix with elements in each row reversed
     * post-condition: original matrix is unchanged
     */
	public int[][] reversalOfElementsInEachRow( int[][] data ) {
		int[][] copy = new int[data.length][];
		
		for (int r = 0; r < data.length; r++) {
			copy[r] = new int[data[r].length];
			for (int c = 0; c < data[r].length; c++) {
				copy[r][c] = data[r][c];
			}
		}
		
		for (int r = 0; r < copy.length; r++) {
			for (int c = 0; c < copy[r].length/2; c++) {
				int temp = copy[r][c];
				copy[r][c] = copy[r][copy[r].length - 1 - c];
				copy[r][copy[r].length - 1 - c] = temp;
			}
		}
		return copy;
    }
	
	/**
     * Reverses all the elements
     * @param data - matrix to be reversed
     * @return matrix with all elements reversed
     * post-condition: original matrix is unchanged
     */
	
	public int[][] reversalOfAllElements(int[][] data) {
		int[][] copy = new int[data.length][];
		
		for (int r = 0; r < data.length; r++) {
			copy[r] = data[data.length - 1 - r];
		}
		copy = reversalOfElementsInEachRow(copy);
		return copy;
	}
}