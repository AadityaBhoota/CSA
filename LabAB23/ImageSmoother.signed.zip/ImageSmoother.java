/**
 * Last name: Bhoota 
 * First name: Aaditya 
 * Student ID: 12110538 
 * Period: 3
 */
public class ImageSmoother {
	/**
     * Smoothen the image for non-edge locations
     * @param image to be smoothened
     * @return image with its edges smoothened
     */
    public int[][] imageSmootherEasy( int[][] image ) {
       int[][] copy = new int[image.length][image.length];
       for (int r = 0; r < image.length; r ++){
          for (int c = 0; c < image[r].length; c ++) {
             copy[r][c] = image[r][c];
          }
       }
       for (int row = 1; row < image.length - 1; row ++) {
    	   for (int col = 1; col < image[row].length - 1; col ++) {
    		   int sum = 0;
    		   for (int r = row - 1; r <= row + 1; r++) {
    	    	   for (int c = col - 1; c <= col + 1; c ++) {
    	    		   sum += image[r][c];
    	    	   }
    		   }
    		   copy[row][col] = sum/9;
    	   }
       }
       return copy;
       
       
    }

	/**
	 * Smoothen the image for all locations
	 * 
	 * @param image to be smoothened
	 * @return image with its edges smoothed
	 */
	public int[][] imageSmootherHard(int[][] image) {
		int[][] copy = new int[image.length + 2][image.length + 2];
		for (int r = 0; r < image.length; r++) {
			for (int c = 0; c < image[r].length; c++) {
				copy[r + 1][c + 1] = image[r][c];
			}
		}
		copy = imageSmootherEasy(copy);
		int[][] temp = new int[image.length][image.length];
		for (int r = 1; r < copy.length - 1; r++) {
			for (int c = 1; c < copy[r].length - 1; c++) {
				temp[r - 1][c - 1] = copy[r][c];
			}
		}
		return temp;

	}
}