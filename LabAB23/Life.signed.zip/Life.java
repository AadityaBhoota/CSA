import java.io.File;
import java.util.Scanner;

/**
 * @author Aaditya Bhoota
 * period 3
 */
public class Life {
	char[][] grid;
	int numBacteria;

	/**
	 * constructor reads in the data from the given file and sets up the life matrix
	 * 
	 * @param fname - name of file
	 */
	public Life(String fname) {
		try {
			Scanner sc = new Scanner(new File(fname));
			grid = new char[20][20];
			numBacteria = sc.nextInt();
			for (int i = 1; i <= numBacteria; i++) {
				int r = sc.nextInt() - 1;
				int c = sc.nextInt() - 1;
				if (r < 20 && c < 20) {
					grid[r][c] = '*';
				}
			}
			for (char[] r : grid) {
				for (int c = 0; c < r.length; c++) {
					if (r[c] != '*') {
						r[c] = ' ';
					}
				}
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	/**
	 * method to print the life matrix
	 */
	public void printMatrix() {
		System.out.printf("\t");
		for (int i = 1; i <= 20; i++) {
			System.out.print(i % 10);
		}
		System.out.print("\n\n");
		for (int r = 0; r < grid.length; r++) {
			System.out.print(r + 1 + "\t");
			for (int c = 0; c < grid[r].length; c++) {
				System.out.print(grid[r][c]);
			}
			System.out.println();
		}

	}

	/**
	 * Method to count the number of neighbors of the given cell in the life matrix
	 * 
	 * @param row - row number
	 * @param col - column number
	 * @return - number of neighbors of the given cell
	 */
	public int numberOfNeighbors(int row, int col) {
		char[][] copy = new char[22][22];
		int count = 0;
		for (int r = 0; r < copy.length; r++) {
			for (int c = 0; c < copy[r].length; c++) {
				if (r == 0 || c == 0 || r == copy.length - 1 || c == copy.length - 1) {
					copy[r][c] = ' ';
				} else {
					copy[r][c] = grid[r - 1][c - 1];
				}
			}
		}
		// Index of copy is shifted one down and one to the right since it is 2 rows and
		// 2 columns bigger
		int copyRow = row + 1;
		int copyCol = col + 1;

		for (int r = copyRow - 1; r <= copyRow + 1; r++) {
			for (int c = copyCol - 1; c <= copyCol + 1; c++) {
				// Only increments count if the cell is not the same as the one that the method
				// is finding neighbors of
				if (copy[r][c] == '*' && (r != copyRow || c != copyCol)) {
					count++;
				}
			}
		}
		return count;
	}

	/**
	 * method to determine if given cell is empty
	 * 
	 * @param row - cell row number
	 * @param col - cell column number
	 * @return true if it is empty, false otherwise
	 */
	private boolean isEmpty(char[][] mat, int row, int col) {
		return mat[row][col] == ' ';
	}

	/**
	 * method that simulates the game of life
	 */
	public void generation() {
		// Use a temp array to change values without messing up the original matrix
		char[][] copy = new char[20][20];
		for (int r = 0; r < 20; r++) {
			for (int c = 0; c < 20; c++) {
				copy[r][c] = grid[r][c];
			}
		}

		for (int r = 0; r < 20; r++) {
			for (int c = 0; c < 20; c++) {
				int numNeighbors = numberOfNeighbors(r, c);
				// kills bacteria if cell isn't empty and there are too many/few neighboring
				// bacteria
				if (!(isEmpty(grid, r, c))) {
					if (numNeighbors <= 1 || numNeighbors >= 4) {
						copy[r][c] = ' ';
						numBacteria--;
					}
				} else {
					if (numNeighbors == 3) {
						copy[r][c] = '*';
						numBacteria ++;
					}
				}
			}
		}

		// set entire temp array to original matrix to transfer all changes
		// simultaneously
		for (int r = 0; r < 20; r++) {
			for (int c = 0; c < 20; c++) {
				grid[r][c] = copy[r][c];
			}
		}

	}

	/**
	 * Method to print the statistics
	 */
	public void printStatistics() {
		int bacteriaInRow10 = 0;
		int bacteriaInCol10 = 0;
		for (char bact : grid[9]) {
			if (bact == '*') {
				bacteriaInRow10++;
			}
		}
		for (int r = 0; r < grid.length; r++) {
			if (grid[r][9] == '*') {
				bacteriaInCol10++;
			}
		}
		System.out.print("Number in Row 10 ---> " + bacteriaInRow10 + "\n" + "Number in Column 10 ---> "
				+ bacteriaInCol10 + "\n" + "Number of living organisms ---> " + numBacteria + "\n");
	}
}