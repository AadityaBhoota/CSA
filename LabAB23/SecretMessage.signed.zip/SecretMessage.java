import java.io.File;
import java.util.Scanner;

/**
 * @author Aaditya Bhoota period 3
 */
public class SecretMessage {
	private char[][] message;
	private char[][] cover;
	private final int maxColumns = 80;
	private int startRow;
	private int startCol;
	// Do not add any other instance variables

	/**
	 * Constructor to read the plain text messages and the cover messages from the
	 * given file. Calls getSecretMessage to reveal the secret message from under
	 * the cover. Then prints the secret message
	 * 
	 * @param fname - file name
	 */
	public SecretMessage(String fname) {
		try {
			Scanner sc = new Scanner(new File(fname));
			int tests = sc.nextInt();
			for (int i = 1; i <= tests; i++) {

				int mLines = sc.nextInt();
				message = new char[mLines][maxColumns];

				// Used to skip to first message Line
				sc.nextLine();

				for (int r = 0; r < mLines; r++) {
					String messageLine = sc.nextLine();
					for (int c = 0; c < messageLine.length(); c++) {
						message[r][c] = messageLine.charAt(c);
					}
				}

				startRow = sc.nextInt();
				startCol = sc.nextInt();
				int cLines = sc.nextInt();
				sc.nextLine();
				cover = new char[cLines][maxColumns];

				for (int r = 0; r < cLines; r++) {
					String coverLine = sc.nextLine();
					for (int c = 0; c < coverLine.length(); c++) {
						cover[r][c] = coverLine.charAt(c);
					}
				}

				System.out.println(getSecretMessage());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Method that extracts the secret message from under the cover cover is placed
	 * at startRow and startCol. If the element in cover is 'O', the corresponding
	 * letter in the message is extracted
	 * 
	 * @return the secret message
	 */
	public String getSecretMessage() {
		String str = "";
		for (int r = 0; r < cover.length; r++) {
			for (int c = 0; c < cover[r].length; c++) {
				if (cover[r][c] == 'O') {
					str += message[r + startRow][c + startCol] + "";
				}
			}
		}
		return str;
	}
}