import java.io.File;
import java.util.Scanner;
/**
 * Last name: Bhoota
 * First name: Aaditya
 * Student ID: 12110538
 * Period: 3S
 */
public class LatinSquare {
	private int[][] mat;
	Scanner sc;
	/**
	 * Constructor initializes mat by reading in data from
	 * the given file
	 * @param fname - input file name
	 */
	public LatinSquare(String fname) {
		try {
			sc = new Scanner(new File(fname));
			mat = new int[sc.nextInt()][sc.nextInt()];
			for (int row = 0; row < mat.length; row++) {
				for (int col = 0; col < mat[row].length; col++) {
					mat[row][col] = sc.nextInt();
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	/**
	 * Checks if the given row of mat contains val
	 * @param row - row to check
	 * @param val - value to look for
	 * @return number of times val occurs in given row of mat
	 */
	public int countValueInRow(int row, int val) {
		int count = 0;
		for (int r : mat[row]) {
			if (r == val) {
				count ++;
			}
		}
		return count;
	}
	/**
	 * Checks if the given col of mat contains val
	 * @param col - column to check
	 * @param val - value to look for
	 * @return number of times val occurs in given column of mat
	 */
	public int countValueInColumn(int col, int val) {
		int count = 0;
		for (int[] r : mat) {
			if (r[col] == val) {
				count++;
			}
		}
		return count;
	}
	/**
	 * Checks if the mat is a Latin Matrix
	 * @return true if it is a Latin Matrix, false otherwise
	 */
	public boolean isLatin() {
		for (int row = 0; row < mat.length; row++) {
			for (int col = 0; col < mat[row].length; col++) {
				int val = mat[row][col];
				if (countValueInColumn(col, val) != 1 || countValueInRow(row, val) != 1 || val < 0 || val >= mat.length) {
					return false;
				}
			}
		}
		return true;
	}
	/**
	 * Method to return the matrix as a string for printing
	 * @return string to print the matrix
	 */
	public String toString() {
		String str = "";
		for (int [] r : mat) {
			for (int c : r) {
				str += c + " ";
			}
			str += "\n";
			
		}
		return str;
	}
}