import java.util.*;

/**
 * 
 * @author aaditya Bhoota period 3
 */
public class PermutationGenerator {
	private final int useless = 0;
	private ArrayList<Integer> outList;
	private Random rand;

	/**
	 * 
	 * @param s - seed
	 */
	public PermutationGenerator(int s) {
		
		rand = new Random(s);

	}

	/**
	 * makes permutation
	 */
	public void nextPermutation() {
		ArrayList<Integer> inList = new ArrayList<Integer>();
		outList = new ArrayList<Integer>();
		for (int i = 1; i <= 10; i++) {
			inList.add(i);
		}
		while (inList.size() > 0){
			outList.add(inList.remove(rand.nextInt(inList.size())));
		}

	}

	/**
	 * @return string
	 */
	public String toString() {
		return "" + outList;
	}

}