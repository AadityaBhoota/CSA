import java.util.*;

/**
 *   
 * @author aaditya Bhoota
 * Period 3
 */
public class Rolling {
	Random rand;
	/**
	 * constructor to initilize the random number
	 * generator
	 * @param s - seed for the random number generator
	 */
	public Rolling(int s)
	{
		rand = new Random(s);//makes new number generator
	}
	/**
	 * Method to simulate a dice roll
	 * @return an integer between 1 and 6
	 */
    private int roll() 
    { 
    	int x = rand.nextInt(6) + 1;
        return x;
    }
    
    /**  
     * Roll the dice three times and count the
     * number of tries it took to get all three
     * different rolls. In the end print a message
     * displaying the number of tries
     */
    public  void play() {
    	int count = 1;
    	int a = roll();
        int b = roll();
        int c = roll();
        System.out.println(a + " " + b + " "+ c);
    	while (a == b || a == c || b == c) {
    		count ++;
    		a = roll();
    		b = roll();
    		c = roll();
    		System.out.println(a + " " + b + " "+ c);
    	}
        System.out.println("Rolled " + count + " times before all the rolls were different");
    }


    /** 
     * Answer to question 3 goes here
     *  (a != b && a != b && b!= c) 
     */
  
} 