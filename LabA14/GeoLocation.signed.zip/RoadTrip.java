import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @author aaditya bhoota
 *
 */

public class RoadTrip {
	// list of geo locations
	// your code goes here
	Scanner scan;
	ArrayList<GeoLocation> list;
	int numStops;

	/**
	 * Constructor reads in the geo locations from the given file and adds them to
	 * the list
	 * 
	 * @param fname - file name
	 */
	public RoadTrip(String fname) {
		list = new ArrayList<GeoLocation>();
		numStops = 0;
		try {
			scan = new Scanner(new File(fname));
			while (scan.hasNext()) {
				addStop(scan.next(), scan.nextDouble(), scan.nextDouble());
				numStops++;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Create a GeoLocation and add it to the road trip
	 * 
	 * @param name      - name of the geo location
	 * @param latitude  - latitude in degrees
	 * @param longitude - longitude in degrees
	 */

	public void addStop(String name, double latitude, double longitude) {
		GeoLocation geo = new GeoLocation(name, latitude, longitude);
		list.add(geo);
	}

	/**
	 * Get the total number of stops in the trip
	 * 
	 * @return total number of stops
	 */
	public int getNumberOfStops() {
		return numStops;
	}

	/**
	 * Get the total miles of the trip
	 * 
	 * @return the total miles
	 */

	public double getTripLength() {
		double totalDistance = 0;
		for (int i = 0; i < list.size() - 1; i++) {
			totalDistance += list.get(i).distanceFrom(list.get(i + 1));
		}
		return totalDistance;
	}

	/**
	 * Return a formatted toString of the trip
	 * 
	 * @return information about the trip
	 */

	public String toString() {
		String str = "";
		for (GeoLocation elem : list) {
			str += elem.toString() + "\n";
		}
		return str + "Stops: " + getNumberOfStops() + "\nTotal miles: " + getTripLength() + " miles\n";
	}
}