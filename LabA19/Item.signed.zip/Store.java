import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author last name: Bhoota
 * first name: Aaditya
 * student ID: 12110538
 * period 3
 */
public class Store {
    private ArrayList<Item> myStore = new ArrayList<Item>();
    Scanner sc;

    /**
     *
     * @param fName - file name
     */
    public Store(String fName) {
        try {
            sc = new Scanner(new File(fName));
        }
        catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
        loadFile();
    }

    /**
     *  default constructor
     */
    public Store() {
        loadFile();
    }

    /**
     * Loads file
     */
    private void loadFile() {
        while (sc.hasNextInt()) {
            myStore.add(new Item(sc.nextInt(), sc.nextInt()));
        }
    }

    /**
     * Displays store contents
     */
    public void displayStore() {
        System.out.print(this.toString());
    }

    /**
     *
     * @return s - returns Store as string
     */
    public String toString() {
        String s = String.format("%10s%10s\n\n", "Id", "Inv");
        for(int i = 0; i < myStore.size(); i++) {
            s += String.format("%2d%s\n", i + 1, myStore.get(i));
            if ((i + 1)% 10 == 0) {
                s += "\n";
            }
        }
        return s;
    }

    /**
     * Sorts arrayList
     */
    public void sort() {
        mergeSort(myStore, 0, myStore.size() - 1);
    } //to get recursive sort going

    /**
     *
     * @param a - arrayList to be sorted
     * @param first - first index where sorting starts
     * @param mid - middle index of arrayList
     * @param last - last index of arrayList
     */
    private void merge(ArrayList<Item> a, int first, int mid, int last) {
        ArrayList<Item> temp = new ArrayList<Item>(a.size());

        int i = first;
        int j = mid;

        while (i < mid && j <= last) {
            if (a.get(i).compareTo(a.get(j)) > 0) {
                temp.add(a.get(j));
                j++;
            } else {
                temp.add(a.get(i));
                i++;
            }
        }
        while (i < mid) {
            temp.add(a.get(i));
            i++;
        }
        while (j <= last) {
            temp.add(a.get(j));
            j++;
        }
        for (int x = first; x <= last; x++) {
            a.set(x, temp.get(x - first));
        }
    }

    /**
     *
     * @param a - arrayList to be sorted
     * @param first - first index of arrayList
     * @param last - last index of arrayList
     */
    public void mergeSort(ArrayList<Item> a, int first, int last) {
        if (last - first >= 1) {
            int mid = (last + first) / 2;
            mergeSort(a, first, mid);
            mergeSort(a, mid + 1, last);
            merge(a, first, mid + 1, last);
        }
    }
}