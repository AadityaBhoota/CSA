import java.util.Scanner;

/**
 * Class to simulate the game of Tic Tac Toe
 * 
 * @author Aaditya Bhoota period 3
 *
 */
public class TicTacToe {
	private final int BOARD_SIZE = 9;
	private char[] board = new char[BOARD_SIZE];
	private char currentPlayer;

	/**
	 * constructor to initialize the board to '-' and myPlayer to 'X'
	 * 
	 */
	public TicTacToe() {
		currentPlayer = 'X';
		for (int i = 0; i < board.length; i++) {
			board[i] = '-';
		}
	}

	/**
	 * Checks if the move location is not already occupied Returns true if it is not
	 * already occupied and false otherwise
	 * 
	 * @param loc - move location where X or O is to be placed on the board
	 * @return true if the location is not already occupied by X or O, false
	 *         otherwise
	 */
	private boolean isOccupied(int loc) {
		return board[loc] != '-';
	}

	/**
	 * Perform one move for the given player if the given location is unoccupied
	 * 
	 * @param player - current player (X or O)
	 * @param loc    - move location where X or O is to be placed on the board
	 * @return true if the move is made, false otherwise
	 */
	private boolean move(char player, int loc) {
		if (!(isOccupied(loc))) {
			board[loc] = player;
			return true;
		}
		return false;
	}

	/**
	 * Returns '-' if there is a '-' found on the board and 't' otherwise
	 * 
	 * @return '-' if '-' is found on the board, otherwise return 't' to indicate a
	 *         tie
	 */
	private char tie() {
		for (char i : board) {
			if (i == '-') {
				return '-';
			}
		}
		return 't';
	}

	/**
	 * Checks to see if the game is over. If the game is over, is there a winner. If
	 * there is a winner, returns 'X' or 'O'. If the game is over but there is no
	 * winner returns 't' indicating a tie If the game is not over, returns a '-'
	 * 
	 * @return 'X' or 'O' or '-' or 't'
	 */
	private char whoWon() {
		
		if ((
			board[0] == board[1] && board[1] == board[2] ||
			board[0] == board[3] && board[3] == board[6] || 
			board[0] == board[4] && board[4] == board[8]) && 
			isOccupied(0)){ 
			return board[0];
		}else if((
			board[3] == board[4] && board[4] == board[5] ||
			board[1] == board[4] && board[4] == board[7] || 
			board[6] == board[4] && board[4] == board[2]) && 
			isOccupied(4)) {
			return board[4];
		}else if ((
			board[6] == board[7] && board[7] == board[8] ||
			board[2] == board[5] && board[5] == board[8]) && 
			isOccupied(8)) {
			return board[8];
		} else {
			return tie();
		}
		
	}

	/**
	 * Prints the board as a 3x3 grid
	 */
	private void printBoard() {
		for (int i = 0; i < board.length; i++) {
			if (i == 2 || i == 5 || i == 8) {
				System.out.println(board[i]);
			} else {
				System.out.print(board[i] + " ");
			}

		}
	}

	/**
	 * Determines whose turn it is. The first player is always X
	 * 
	 * @param turnNumber - number of the turn
	 * @return - 'X' or 'O' based on whose turn it is
	 */
	private char determineCurrentPlayer(int turnNumber) {
		return turnNumber % 2 == 0 ? 'X' : 'O';
	}
	/**
	 * resets the board
	 */
	private void resetBoard() {
		currentPlayer = 'X';
		for (int i = 0; i < board.length; i++) {
			board[i] = '-';
		}
	}
	
	/**
	 * Plays the game of tic tac toe till the game is over
	 */
	public void playGame() {
		Scanner sc = new Scanner(System.in);
		int turnNumber = 0;
		printBoard();
		while (whoWon() == '-') {
			char player = determineCurrentPlayer(turnNumber);
			System.out.print("Player " + player + " enter a location to place " + player + " : ");
			int loc = sc.nextInt();

			if (loc > 8 || loc < 0) {
				System.out.println("Location selected (" + loc + ") is not valid. Enter a number between 0 and 8 inclusive");
			} else if(isOccupied(loc) ) {
				System.out.println("The location selected (" + loc + ") is occupied.");
			} else {
				move(player, loc);
				turnNumber ++;
				printBoard();
			}


			if (whoWon() != '-') {
				if(whoWon() == 't') {
					System.out.println("Its a tie!");
				}else {
					System.out.println("Player " + player + " won!");
				}
			}
		}
	}
}