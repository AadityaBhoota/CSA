import java.util.*;
import java.io.*;

/**
 * 
 * @author Aaditya Bhoota period 3
 */
public class Compact {
	private final int MAXSIZE = 100;
	private int[] myArray;
	private int arraySize;

	/**
	 * 
	 * @param fname - name of file
	 */
	public Compact(String fname) {
		myArray = new int[MAXSIZE];
		try {
			Scanner file = new Scanner(new File(fname));
			int i = 0;
			while (file.hasNext()) {
				myArray[i] = file.nextInt();
				i++;
			}
			arraySize = i;
			file.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * compacts the array
	 */
	public void compactIt() {
		System.out.print("Before: ");
		printArray();
		System.out.println();
		int numZero = 0;
		for (int i = 0; i < myArray.length - numZero; i++) {
			if (myArray[i] == 0) {
				numZero++;
				for (int j = i; j < arraySize; j++) {
					if (j + 1 < arraySize) {
						myArray[j] = myArray[j + 1];
					}
				}
				i--;
				myArray[arraySize - 1] = 0;
			}
		}
		System.out.print("After: ");
		printArray();
		System.out.println();
	}

	/**
	 * Prints the array
	 */
	private void printArray() {
		System.out.print(myArray[0]);
		for (int i = 1; i < arraySize; i++) {
			System.out.print(" " + myArray[i]);
		}
	}
}