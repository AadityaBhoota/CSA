/**
 * Determines the primes less than or equal to n using the Sieve of Eratosthenes
 * 
 * @author Aaditya Bhoota period 3
 *
 */
public class Eratosthenes {
	private int[] allNumbers;
	private int length;
	// Your fields go here

	/**
	 * Constructor to initialize array of primes using the Sieve of Eratosthenes
	 * 
	 * @param n - all primes are less than or equal to n
	 */
	public Eratosthenes(int n) {
		length = n - 1;
		allNumbers = new int[length];
		for (int i = 0; i < length; i++) {
			allNumbers[i] = i + 2;
		}
	}

	/**
	 * Count the number of primes
	 * 
	 * @return number of primes less than or equal to n
	 */
	public int countPrimes() {
		return length;
	}

	/**
	 * returns a list of primes less than or equal to n
	 * 
	 * @return - returns array of primes
	 */
	public int[] listOfPrimes() {

		for (int i = 0; i < length; i++) {
			int num = allNumbers[i];
			for (int j = i + 1; j < length; j++) {
				if (allNumbers[j] % num == 0) {
					for (int k = j; k < length; k++) {
						if (k != length - 1) {
							allNumbers[k] = allNumbers[k + 1];
						}
					}
					length--;
				}
			}
		}
		int[] returnArray = new int[length];
		for (int l = 0; l < length; l++) {
			returnArray[l] = allNumbers[l];
		}
		return returnArray;
	}

   /**
   * @return - Returns a string containing the prime numbers and the number of prime numbers
   * in the list
   * 
   */
	public String toString() {
		String str = "";
		int[] temp = listOfPrimes();
		for (int i : temp) {
			str += " " + i;
		}
		str = str.substring(1);
		str += "\nNumber of primes less than or equal to " + (allNumbers.length + 1) + " = " + countPrimes();
		return str;
	}
}